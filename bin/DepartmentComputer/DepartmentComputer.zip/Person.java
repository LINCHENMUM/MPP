package DepartmentComputer;

public abstract class Person {
	protected String name;
	protected String phone;
	protected int age;
	
	//abstract double getSalary();

}
